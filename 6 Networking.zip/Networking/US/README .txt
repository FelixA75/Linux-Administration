NetworkInfo.sh is stored in one of my directories named "MyScripts". Its path would be HOME/MyScripts. If you were to use it on your machine, it would not work. To get it to work on your machine, open the file in a text editor and in line 4 change the destination to your desired one.


The file will create logs and save them to a directory called "Network". The code for this is located in line 7. However, you do not have to change this portion unless you have a directory named Network and use it for a different purpose. Otherwise, leave it alone and it will create a new directory named Network where it will store the log files.

Link to file:

https://github.com/FelixA75/Linux-Administration/blob/main/NetworkInfo.sh